n = 50

n.times do |i|
    
    print "Iteración #{i}"
    i = i + 1
    print "\n"

end