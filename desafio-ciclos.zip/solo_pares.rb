n  = ARGV[0].to_i
n.times do |i|
  print 2*i
  print "\n"
end

#uso ruby solo_pares.rb 
# pares desde el 0

