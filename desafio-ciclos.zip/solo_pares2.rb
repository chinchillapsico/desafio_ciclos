n  = ARGV[0].to_i
n.times do |i|
  print 2*(i + 1)
  print "\n"
end
#uso ruby solo_pares2.rb 4
# pares  sin el cero.


