n  = ARGV[0].to_i
suma = 0

n.times do |i|
  suma += 2*(i + 1)
end

print suma
